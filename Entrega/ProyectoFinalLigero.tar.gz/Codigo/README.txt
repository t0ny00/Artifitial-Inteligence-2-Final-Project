# Universidad Simón Bolívar
# Inteligencia Artificial II
# Prof. Ivette Carolina Martínez
# Alumnos:
# Carlos Martinez 11-10584
# Yerson Roa 11-10876
# Antonio Scaramazza 11-10957

Esta carpeta contiene todos los archivos necesarios para la implementacion del proyecto final de inteligencia artificial II. A continuacion se describen cada archivo:

Utils.py: contiene funciones de apoyo utilizadas durante la extraccion y manejo de las canciones asi como de sus generos. Su uso ya no es necesario debido a que se entrega de antemano el set de canciones utilizadas en la red neural

extractSong.py: script simple que llama en el orden adecuado a las funciones definidas en Utils.py, su uso no es necesario para reproducir los resultados del proyecto y requiere del subset completo de la MSD.


lista_final.cls: archivo que contiene el track-id y el genero de las 599 canciones seleccionadas para su uso en el proyecto.

Carpeta canciones: este directorio contiene en total 599 canciones previamente seleccionadas para su uso en la red neural

Carpeta MSongsDB: contiene las funciones definidas por los autores de la MSD para acceder de manera rapida a la informacion contenida en los archivos de las canciones.

NeuralNetwork.py: contiene el codigo con el cual se realizo el proyecto final y se obtuvieron los resultados expuestos en el informe.
    Uso: python NeuralNetwork.py
    Requisitos: archivo lista_final.cls
                Carpeta canciones
                Carpeta MSongsDB
