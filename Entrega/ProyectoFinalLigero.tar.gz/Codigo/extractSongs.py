import Utils as util


util.extractGenre()
util.findSongsInData()
util.move_files()
